(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__da734520._.css",
  "static/chunks/05d6d_fe1426f5._.js",
  "static/chunks/3d860_BrowserBase Pipeline_website-genesis-output_landlordos_components_80d1afe8._.js"
],
    source: "dynamic"
});
