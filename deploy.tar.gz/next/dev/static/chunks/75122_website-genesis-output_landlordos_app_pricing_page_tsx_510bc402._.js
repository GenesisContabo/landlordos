(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/05d6d_6bfac864._.js",
  "static/chunks/Desktop_BrowserBase Pipeline_website-genesis-output_landlordos_20f3f8aa._.js"
],
    source: "dynamic"
});
