globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/05d6d_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0ff94f39._.js",
    "static/chunks/05d6d_next_dist_compiled_react-dom_a64ba87c._.js",
    "static/chunks/05d6d_next_dist_compiled_react-server-dom-turbopack_7f9ac2c9._.js",
    "static/chunks/05d6d_next_dist_compiled_next-devtools_index_9214e19e.js",
    "static/chunks/05d6d_next_dist_compiled_01d1cf43._.js",
    "static/chunks/05d6d_next_dist_client_37c7df89._.js",
    "static/chunks/05d6d_next_dist_d96ac8df._.js",
    "static/chunks/05d6d_@swc_helpers_cjs_01b648db._.js",
    "static/chunks/Desktop_BrowserBase Pipeline_website-genesis-output_landlordos_a0ff3932._.js",
    "static/chunks/88e7d_BrowserBase Pipeline_website-genesis-output_landlordos_80f0c4c7._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];