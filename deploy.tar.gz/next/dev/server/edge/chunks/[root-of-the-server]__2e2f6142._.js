(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__2e2f6142._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/csrf.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addCsrfToken",
    ()=>addCsrfToken,
    "csrfErrorResponse",
    ()=>csrfErrorResponse,
    "csrfMiddleware",
    ()=>csrfMiddleware,
    "generateCsrfToken",
    ()=>generateCsrfToken,
    "getCsrfToken",
    ()=>getCsrfToken,
    "verifyCsrfToken",
    ()=>verifyCsrfToken
]);
/**
 * CSRF Protection Implementation
 * Uses Double Submit Cookie pattern
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
;
/**
 * Generate random string without Node.js crypto (Edge Runtime compatible)
 */ function generateRandomToken() {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, (byte)=>byte.toString(16).padStart(2, '0')).join('');
}
const CSRF_TOKEN_NAME = 'csrf-token';
const CSRF_HEADER_NAME = 'x-csrf-token';
const CSRF_SECRET_NAME = 'csrf-secret';
function generateCsrfToken() {
    return generateRandomToken();
}
function verifyCsrfToken(request) {
    const method = request.method.toUpperCase();
    // Only check state-changing methods
    if (![
        'POST',
        'PUT',
        'PATCH',
        'DELETE'
    ].includes(method)) {
        return true;
    }
    // Skip CSRF check for webhooks and public APIs
    const pathname = request.nextUrl.pathname;
    if (pathname.startsWith('/api/stripe/webhook') || pathname.startsWith('/api/auth/callback')) {
        return true;
    }
    // Get token from header
    const headerToken = request.headers.get(CSRF_HEADER_NAME);
    // Get token from cookie
    const cookieToken = request.cookies.get(CSRF_TOKEN_NAME)?.value;
    // Both must exist and match
    if (!headerToken || !cookieToken) {
        return false;
    }
    return headerToken === cookieToken;
}
function addCsrfToken(response) {
    // Check if token already exists
    const existingToken = response.cookies.get(CSRF_TOKEN_NAME);
    if (!existingToken) {
        const token = generateCsrfToken();
        // Set as httpOnly cookie for security
        response.cookies.set(CSRF_TOKEN_NAME, token, {
            httpOnly: true,
            secure: ("TURBOPACK compile-time value", "development") === 'production',
            sameSite: 'lax',
            path: '/',
            maxAge: 60 * 60 * 24
        });
        // Also set a readable version for client to access
        response.cookies.set(CSRF_SECRET_NAME, token, {
            httpOnly: false,
            secure: ("TURBOPACK compile-time value", "development") === 'production',
            sameSite: 'lax',
            path: '/',
            maxAge: 60 * 60 * 24
        });
    }
    return response;
}
function csrfErrorResponse() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].json({
        error: 'Invalid CSRF token. Please refresh the page and try again.'
    }, {
        status: 403
    });
}
function csrfMiddleware(request) {
    // Skip non-API routes
    if (!request.nextUrl.pathname.startsWith('/api')) {
        return null;
    }
    // Verify CSRF token
    if (!verifyCsrfToken(request)) {
        return csrfErrorResponse();
    }
    return null;
}
function getCsrfToken(request) {
    return request.cookies.get(CSRF_SECRET_NAME)?.value;
}
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "middleware",
    ()=>middleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$csrf$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/csrf.ts [middleware-edge] (ecmascript)");
;
;
async function middleware(request) {
    // 1. CSRF Protection for API routes
    if (request.nextUrl.pathname.startsWith('/api')) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$csrf$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["verifyCsrfToken"])(request)) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$csrf$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["csrfErrorResponse"])();
        }
    }
    // 2. Authentication check for protected routes
    // Define public routes that don't require authentication
    const publicRoutes = [
        '/',
        '/pricing',
        '/features',
        '/about',
        '/robots.txt',
        '/sitemap.xml'
    ];
    const isPublicRoute = publicRoutes.some((route)=>request.nextUrl.pathname === route);
    const isAuthRoute = request.nextUrl.pathname.startsWith('/login') || request.nextUrl.pathname.startsWith('/signup');
    // Allow public routes, auth routes, and API auth routes without redirect
    if (isPublicRoute || isAuthRoute || request.nextUrl.pathname.startsWith('/api/auth')) {
        const response = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$csrf$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["addCsrfToken"])(response);
    }
    // For protected routes (like /dashboard), check for session token in cookies
    // NextAuth JWT strategy stores session in a cookie
    const sessionToken = request.cookies.get(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'next-auth.session-token');
    // If no session token, redirect to login
    if (!sessionToken && request.nextUrl.pathname.startsWith('/dashboard')) {
        const loginUrl = new URL('/login', request.url);
        loginUrl.searchParams.set('callbackUrl', request.nextUrl.pathname);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(loginUrl);
    }
    // 3. Add CSRF token to response
    const response = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$csrf$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["addCsrfToken"])(response);
}
const config = {
    matcher: [
        '/((?!_next/static|_next/image|favicon.ico).*)'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__2e2f6142._.js.map