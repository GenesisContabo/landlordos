module.exports = [
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=5b7a5_ebsite-genesis-output_landlordos__next-internal_server_app_page_actions_07f60ff9.js.map