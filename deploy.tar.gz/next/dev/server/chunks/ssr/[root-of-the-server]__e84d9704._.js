module.exports = [
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "invoices",
    ()=>invoices,
    "maintenanceRequests",
    ()=>maintenanceRequests,
    "maintenanceRequestsRelations",
    ()=>maintenanceRequestsRelations,
    "passwordResetTokens",
    ()=>passwordResetTokens,
    "payments",
    ()=>payments,
    "paymentsRelations",
    ()=>paymentsRelations,
    "properties",
    ()=>properties,
    "propertiesRelations",
    ()=>propertiesRelations,
    "tenants",
    ()=>tenants,
    "tenantsRelations",
    ()=>tenantsRelations,
    "units",
    ()=>units,
    "unitsRelations",
    ()=>unitsRelations,
    "users",
    ()=>users,
    "usersRelations",
    ()=>usersRelations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/table.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/uuid.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/varchar.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/text.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/timestamp.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$numeric$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/numeric.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$boolean$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/boolean.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$date$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/columns/date.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$checks$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/pg-core/checks.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/relations.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$sql$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/sql/sql.js [app-rsc] (ecmascript)");
;
;
const users = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('users', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    email: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('email', {
        length: 255
    }).notNull().unique(),
    passwordHash: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('password_hash', {
        length: 255
    }).notNull(),
    name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('name', {
        length: 255
    }).notNull(),
    emailVerified: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$boolean$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["boolean"])('email_verified').default(false),
    stripeCustomerId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('stripe_customer_id', {
        length: 255
    }).unique(),
    subscriptionStatus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('subscription_status', {
        length: 50
    }).default('free'),
    subscriptionTier: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('subscription_tier', {
        length: 50
    }).default('free'),
    subscriptionPeriodEnd: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('subscription_period_end'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('updated_at').defaultNow()
});
const properties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('properties', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    userId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('user_id').notNull().references(()=>users.id, {
        onDelete: 'cascade'
    }),
    name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('name', {
        length: 255
    }).notNull(),
    address: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('address'),
    notes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('notes'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('updated_at').defaultNow()
});
const units = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('units', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    propertyId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('property_id').notNull().references(()=>properties.id, {
        onDelete: 'cascade'
    }),
    unitNumber: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('unit_number', {
        length: 50
    }).notNull(),
    rentAmount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$numeric$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["decimal"])('rent_amount', {
        precision: 10,
        scale: 2
    }).notNull(),
    status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('status', {
        length: 50
    }).default('vacant'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('updated_at').defaultNow()
}, (table)=>({
        rentCheck: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$checks$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["check"])('rent_check', __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$sql$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["sql"]`${table.rentAmount} >= 0`)
    }));
const tenants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('tenants', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    unitId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('unit_id').references(()=>units.id, {
        onDelete: 'set null'
    }),
    name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('name', {
        length: 255
    }).notNull(),
    email: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('email', {
        length: 255
    }),
    phone: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('phone', {
        length: 50
    }),
    leaseStart: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$date$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["date"])('lease_start'),
    leaseEnd: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$date$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["date"])('lease_end'),
    status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('status', {
        length: 50
    }).default('active'),
    moveOutDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$date$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["date"])('move_out_date'),
    notes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('notes'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('updated_at').defaultNow()
});
const payments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('payments', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    tenantId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('tenant_id').notNull().references(()=>tenants.id, {
        onDelete: 'cascade'
    }),
    amount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$numeric$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["decimal"])('amount', {
        precision: 10,
        scale: 2
    }).notNull(),
    paymentDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$date$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["date"])('payment_date').notNull(),
    paymentMethod: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('payment_method', {
        length: 50
    }),
    notes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('notes'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow()
}, (table)=>({
        amountCheck: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$checks$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["check"])('amount_check', __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$sql$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["sql"]`${table.amount} > 0`)
    }));
const maintenanceRequests = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('maintenance_requests', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    unitId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('unit_id').notNull().references(()=>units.id, {
        onDelete: 'cascade'
    }),
    title: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('title', {
        length: 255
    }).notNull(),
    description: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('description').notNull(),
    status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('status', {
        length: 50
    }).default('open'),
    priority: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('priority', {
        length: 50
    }).default('medium'),
    photoUrl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('photo_url'),
    resolutionNotes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('resolution_notes'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('updated_at').defaultNow(),
    resolvedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('resolved_at')
});
const passwordResetTokens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('password_reset_tokens', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    userId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('user_id').notNull().references(()=>users.id, {
        onDelete: 'cascade'
    }),
    tokenHash: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('token_hash', {
        length: 255
    }).notNull().unique(),
    expiresAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('expires_at').notNull(),
    used: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$boolean$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["boolean"])('used').default(false),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow(),
    ipAddress: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('ip_address', {
        length: 45
    })
});
const invoices = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$table$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["pgTable"])('invoices', {
    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('id').defaultRandom().primaryKey(),
    userId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$uuid$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uuid"])('user_id').notNull().references(()=>users.id, {
        onDelete: 'cascade'
    }),
    stripeInvoiceId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('stripe_invoice_id', {
        length: 255
    }).notNull().unique(),
    amount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$numeric$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["decimal"])('amount', {
        precision: 10,
        scale: 2
    }).notNull(),
    status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$varchar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["varchar"])('status', {
        length: 50
    }).notNull(),
    invoiceUrl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$text$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["text"])('invoice_url'),
    createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$pg$2d$core$2f$columns$2f$timestamp$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["timestamp"])('created_at').defaultNow()
});
const usersRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(users, ({ many })=>({
        properties: many(properties),
        invoices: many(invoices)
    }));
const propertiesRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(properties, ({ one, many })=>({
        user: one(users, {
            fields: [
                properties.userId
            ],
            references: [
                users.id
            ]
        }),
        units: many(units)
    }));
const unitsRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(units, ({ one, many })=>({
        property: one(properties, {
            fields: [
                units.propertyId
            ],
            references: [
                properties.id
            ]
        }),
        tenants: many(tenants),
        maintenanceRequests: many(maintenanceRequests)
    }));
const tenantsRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(tenants, ({ one, many })=>({
        unit: one(units, {
            fields: [
                tenants.unitId
            ],
            references: [
                units.id
            ]
        }),
        payments: many(payments)
    }));
const paymentsRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(payments, ({ one })=>({
        tenant: one(tenants, {
            fields: [
                payments.tenantId
            ],
            references: [
                tenants.id
            ]
        })
    }));
const maintenanceRequestsRelations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$relations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["relations"])(maintenanceRequests, ({ one })=>({
        unit: one(units, {
            fields: [
                maintenanceRequests.unitId
            ],
            references: [
                units.id
            ]
        })
    }));
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/db.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "db",
    ()=>db
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$neon$2d$http$2f$driver$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/neon-http/driver.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/@neondatabase/serverless/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript)");
;
;
;
// Validate DATABASE_URL in production runtime
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
    // Allow build to proceed, but warn
    if (("TURBOPACK compile-time value", "undefined") === 'undefined' && process.env.NEXT_PHASE !== 'phase-production-build') {
        // Only throw error at runtime, not build time
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }
    console.warn('WARNING: DATABASE_URL not set, using placeholder (development/build only)');
}
const connectionString = DATABASE_URL || 'postgresql://placeholder:placeholder@localhost/placeholder';
// Additional validation: ensure it's not the placeholder in production runtime
if (("TURBOPACK compile-time value", "undefined") === 'undefined' && process.env.NEXT_PHASE !== 'phase-production-build' && ("TURBOPACK compile-time value", "development") === 'production' && connectionString.includes('placeholder')) //TURBOPACK unreachable
;
const sql = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["neon"])(connectionString);
const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$neon$2d$http$2f$driver$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["drizzle"])(sql, {
    schema: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__
});
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/password.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hashPassword",
    ()=>hashPassword,
    "validatePassword",
    ()=>validatePassword,
    "verifyPassword",
    ()=>verifyPassword
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$bcrypt__$5b$external$5d$__$28$bcrypt$2c$__cjs$2c$__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$bcrypt$29$__ = __turbopack_context__.i("[externals]/bcrypt [external] (bcrypt, cjs, [project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/bcrypt)");
;
const SALT_ROUNDS = 12;
async function hashPassword(password) {
    return __TURBOPACK__imported__module__$5b$externals$5d2f$bcrypt__$5b$external$5d$__$28$bcrypt$2c$__cjs$2c$__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$bcrypt$29$__["default"].hash(password, SALT_ROUNDS);
}
async function verifyPassword(password, hashedPassword) {
    return __TURBOPACK__imported__module__$5b$externals$5d2f$bcrypt__$5b$external$5d$__$28$bcrypt$2c$__cjs$2c$__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$bcrypt$29$__["default"].compare(password, hashedPassword);
}
function validatePassword(password) {
    const errors = [];
    if (password.length < 8) {
        errors.push('Password must be at least 8 characters');
    }
    if (!/[A-Z]/.test(password)) {
        errors.push('Password must contain at least one uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
        errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
        errors.push('Password must contain at least one number');
    }
    return {
        valid: errors.length === 0,
        errors
    };
}
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/auth.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "auth",
    ()=>auth,
    "authConfig",
    ()=>authConfig,
    "handlers",
    ()=>handlers,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next-auth/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f40$auth$2f$core$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/@auth/core/providers/credentials.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/sql/expressions/conditions.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$password$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/password.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
const authConfig = {
    providers: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f40$auth$2f$core$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])({
            name: 'credentials',
            credentials: {
                email: {
                    label: 'Email',
                    type: 'email'
                },
                password: {
                    label: 'Password',
                    type: 'password'
                }
            },
            async authorize (credentials) {
                if (!credentials?.email || !credentials?.password) {
                    return null;
                }
                const user = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"].query.users.findFirst({
                    where: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["users"].email, credentials.email)
                });
                if (!user) {
                    return null;
                }
                const isValid = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$password$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["verifyPassword"])(credentials.password, user.passwordHash);
                if (!isValid) {
                    return null;
                }
                return {
                    id: user.id,
                    email: user.email,
                    name: user.name,
                    subscriptionTier: user.subscriptionTier
                };
            }
        })
    ],
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.id = user.id;
                token.subscriptionTier = user.subscriptionTier;
            }
            return token;
        },
        async session ({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.subscriptionTier = token.subscriptionTier;
            }
            return session;
        }
    },
    pages: {
        signIn: '/login',
        error: '/login'
    },
    session: {
        strategy: 'jwt',
        maxAge: 24 * 60 * 60,
        updateAge: 60 * 60
    },
    secret: process.env.NEXTAUTH_SECRET,
    useSecureCookies: ("TURBOPACK compile-time value", "development") === 'production',
    cookies: {
        sessionToken: {
            name: `${("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : ''}next-auth.session-token`,
            options: {
                httpOnly: true,
                sameSite: 'lax',
                path: '/',
                secure: ("TURBOPACK compile-time value", "development") === 'production'
            }
        }
    }
};
const { handlers, auth, signIn, signOut } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"])(authConfig);
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/stripe.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PRICING",
    ()=>PRICING,
    "stripe",
    ()=>stripe
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$stripe$2f$esm$2f$stripe$2e$esm$2e$node$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/stripe/esm/stripe.esm.node.js [app-rsc] (ecmascript)");
;
// Allow build to proceed without Stripe keys (build time vs runtime)
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder';
const stripe = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$stripe$2f$esm$2f$stripe$2e$esm$2e$node$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"](STRIPE_SECRET_KEY, {
    apiVersion: '2025-12-15.clover',
    typescript: true
});
const PRICING = {
    FREE: {
        name: 'Free',
        price: 0,
        priceId: null,
        features: [
            'Up to 2 properties',
            'Unlimited tenants',
            'Basic rent tracking',
            'Community support'
        ],
        limits: {
            properties: 2,
            storage: 0
        }
    },
    STARTER: {
        name: 'Starter',
        price: 15,
        priceId: process.env.STRIPE_PRICE_STARTER || '',
        features: [
            'Up to 10 properties',
            'Unlimited tenants',
            'Rent tracking',
            'Maintenance requests',
            '100MB document storage',
            'Email support'
        ],
        limits: {
            properties: 10,
            storage: 100 * 1024 * 1024
        }
    },
    PRO: {
        name: 'Pro',
        price: 35,
        priceId: process.env.STRIPE_PRICE_PRO || '',
        features: [
            'Unlimited properties',
            'Unlimited tenants',
            'Full rent tracking',
            'Priority maintenance',
            '5GB document storage',
            'Priority support',
            'Advanced analytics'
        ],
        limits: {
            properties: Infinity,
            storage: 5 * 1024 * 1024 * 1024
        }
    }
};
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/subscription.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkSubscriptionLimit",
    ()=>checkSubscriptionLimit,
    "getOrCreateStripeCustomer",
    ()=>getOrCreateStripeCustomer,
    "getPricingTier",
    ()=>getPricingTier,
    "getUserSubscription",
    ()=>getUserSubscription,
    "updateUserSubscription",
    ()=>updateUserSubscription
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/db.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/sql/expressions/conditions.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/stripe.ts [app-rsc] (ecmascript)");
;
;
;
;
async function getUserSubscription(userId) {
    const user = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"].query.users.findFirst({
        where: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["users"].id, userId),
        columns: {
            id: true,
            email: true,
            stripeCustomerId: true,
            subscriptionStatus: true,
            subscriptionTier: true,
            subscriptionPeriodEnd: true
        }
    });
    return user || null;
}
async function updateUserSubscription(userId, data) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"].update(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["users"]).set({
        ...data,
        updatedAt: new Date()
    }).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["eq"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$schema$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["users"].id, userId));
}
async function getOrCreateStripeCustomer(userId, email) {
    const user = await getUserSubscription(userId);
    // Return existing customer ID if available
    if (user?.stripeCustomerId) {
        return user.stripeCustomerId;
    }
    // Create new Stripe customer
    const customer = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripe"].customers.create({
        email,
        metadata: {
            userId
        }
    });
    // Save customer ID to database
    await updateUserSubscription(userId, {
        stripeCustomerId: customer.id
    });
    return customer.id;
}
async function checkSubscriptionLimit(userId, limitType) {
    const user = await getUserSubscription(userId);
    const tier = (user?.subscriptionTier || 'free').toUpperCase();
    const limits = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PRICING"][tier]?.limits || __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PRICING"].FREE.limits;
    let current = 0;
    if (limitType === 'properties') {
        // Count user's properties
        const { properties } = await __turbopack_context__.A("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript, async loader)");
        const { count } = await __turbopack_context__.A("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/index.js [app-rsc] (ecmascript, async loader)");
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$db$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"].select({
            count: count()
        }).from(properties).where((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$drizzle$2d$orm$2f$sql$2f$expressions$2f$conditions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["eq"])(properties.userId, userId));
        current = result[0]?.count || 0;
    }
    const limit = limits[limitType];
    const allowed = current < limit;
    return {
        allowed,
        current,
        limit,
        tier: tier.toLowerCase()
    };
}
function getPricingTier(tier) {
    const normalizedTier = (tier || 'free').toUpperCase();
    return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PRICING"][normalizedTier] || __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$stripe$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PRICING"].FREE;
}
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
// This file is generated by next-core EcmascriptClientReferenceModule.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx <module evaluation>", "default");
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
// This file is generated by next-core EcmascriptClientReferenceModule.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx", "default");
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$app$2f$pricing$2f$PricingClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$app$2f$pricing$2f$PricingClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$app$2f$pricing$2f$PricingClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PricingPage,
    "metadata",
    ()=>metadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/auth.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$subscription$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/subscription.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$app$2f$pricing$2f$PricingClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/PricingClient.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$metadata$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/metadata.ts [app-rsc] (ecmascript)");
;
;
;
;
;
const metadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$metadata$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createMetadata"])({
    title: 'Pricing Plans',
    description: 'Choose the perfect plan for your property management needs. Flexible pricing for landlords of all sizes.',
    path: '/pricing'
});
async function PricingPage() {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["auth"])();
    const userId = session?.user?.id;
    let currentTier = 'free';
    if (userId) {
        const userSubscription = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$subscription$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getUserSubscription"])(userId);
        currentTier = userSubscription?.subscriptionTier?.toLowerCase() || 'free';
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$app$2f$pricing$2f$PricingClient$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        currentTier: currentTier
    }, void 0, false, {
        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/page.tsx",
        lineNumber: 22,
        columnNumber: 10
    }, this);
}
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/pricing/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e84d9704._.js.map