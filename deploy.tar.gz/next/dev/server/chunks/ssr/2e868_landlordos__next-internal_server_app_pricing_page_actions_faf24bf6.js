module.exports = [
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/.next-internal/server/app/pricing/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_pricing_page_actions_faf24bf6.js.map