module.exports = [
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/schema.ts [app-rsc] (ecmascript)");
    });
});
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/05d6d_drizzle-orm_6f087469._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/drizzle-orm/index.js [app-rsc] (ecmascript)");
    });
});
}),
];