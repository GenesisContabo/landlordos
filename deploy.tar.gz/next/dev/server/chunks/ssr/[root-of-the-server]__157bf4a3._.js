module.exports = [
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico.mjs { IMAGE => \"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/components/seo/JsonLd.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Schema.org JSON-LD Component for SEO
__turbopack_context__.s([
    "breadcrumbSchema",
    ()=>breadcrumbSchema,
    "default",
    ()=>JsonLd,
    "organizationSchema",
    ()=>organizationSchema,
    "softwareApplicationSchema",
    ()=>softwareApplicationSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function JsonLd({ data }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
        type: "application/ld+json",
        dangerouslySetInnerHTML: {
            __html: JSON.stringify(data)
        }
    }, void 0, false, {
        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/components/seo/JsonLd.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'LandlordOS',
    url: 'https://landlordos.com',
    logo: 'https://landlordos.com/logo.png',
    description: 'Modern property management software for landlords',
    address: {
        '@type': 'PostalAddress',
        addressCountry: 'US'
    },
    sameAs: [
        'https://twitter.com/landlordos',
        'https://linkedin.com/company/landlordos'
    ]
};
const softwareApplicationSchema = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'LandlordOS',
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    offers: {
        '@type': 'Offer',
        price: '29',
        priceCurrency: 'USD',
        priceSpecification: {
            '@type': 'UnitPriceSpecification',
            price: '29',
            priceCurrency: 'USD',
            unitText: 'MONTH'
        }
    },
    description: 'Property management software for landlords to manage properties, tenants, maintenance, and rent payments',
    aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: '4.8',
        ratingCount: '127'
    }
};
const breadcrumbSchema = (items)=>({
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: items.map((item, index)=>({
                '@type': 'ListItem',
                position: index + 1,
                name: item.name,
                item: item.url
            }))
    });
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home,
    "metadata",
    ()=>metadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$metadata$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/lib/metadata.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$components$2f$seo$2f$JsonLd$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/components/seo/JsonLd.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
;
;
;
;
const metadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$lib$2f$metadata$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createMetadata"])({
    title: 'LandlordOS',
    description: 'Modern property management software for landlords. Manage properties, tenants, maintenance, and rent payments all in one place.',
    path: '/'
});
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$components$2f$seo$2f$JsonLd$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                data: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$components$2f$seo$2f$JsonLd$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["organizationSchema"]
            }, void 0, false, {
                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$components$2f$seo$2f$JsonLd$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                data: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$components$2f$seo$2f$JsonLd$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["softwareApplicationSchema"]
            }, void 0, false, {
                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-screen",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "relative py-20 sm:py-32 overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center max-w-3xl mx-auto",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6",
                                        children: [
                                            "Property Management",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block text-primary mt-2",
                                                children: "Made Simple"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                                lineNumber: 25,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                        lineNumber: 23,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto",
                                        children: "Modern property management software built for landlords. Manage properties, tenants, maintenance requests, and payments—all in one place."
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                        lineNumber: 27,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col sm:flex-row gap-4 justify-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/signup",
                                                className: "inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-primary rounded-lg hover:bg-primary/90 transition-colors",
                                                children: "Get Started Free"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                                lineNumber: 31,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/pricing",
                                                className: "inline-flex items-center justify-center px-8 py-3 text-base font-medium text-foreground bg-secondary rounded-lg hover:bg-secondary/80 transition-colors",
                                                children: "View Pricing"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                                lineNumber: 37,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                        lineNumber: 30,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                lineNumber: 22,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "py-20 bg-secondary/10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center mb-16",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-3xl sm:text-4xl font-bold mb-4",
                                            children: "Everything You Need"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                            lineNumber: 52,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg text-muted-foreground max-w-2xl mx-auto",
                                            children: "Powerful features designed specifically for landlords managing multiple properties"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                            lineNumber: 55,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid md:grid-cols-2 lg:grid-cols-3 gap-8",
                                    children: [
                                        {
                                            title: 'Property Management',
                                            description: 'Track properties, units, and important details all in one centralized dashboard.'
                                        },
                                        {
                                            title: 'Tenant Portal',
                                            description: 'Give tenants a seamless experience to submit requests and make payments.'
                                        },
                                        {
                                            title: 'Maintenance Tracking',
                                            description: 'Manage maintenance requests from submission to completion with status updates.'
                                        },
                                        {
                                            title: 'Payment Processing',
                                            description: 'Secure online rent collection with automatic receipts and payment history.'
                                        },
                                        {
                                            title: 'Financial Reports',
                                            description: 'Track income, expenses, and generate reports for tax season.'
                                        },
                                        {
                                            title: 'Mobile Friendly',
                                            description: 'Access your dashboard anywhere, anytime from any device.'
                                        }
                                    ].map((feature)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-card p-6 rounded-lg border border-border hover:border-primary/50 transition-colors",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-xl font-semibold mb-3",
                                                    children: feature.title
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                                    lineNumber: 91,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-muted-foreground",
                                                    children: feature.description
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                                    lineNumber: 92,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, feature.title, true, {
                                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                            lineNumber: 87,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "py-20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-3xl sm:text-4xl font-bold mb-4",
                                    children: "Ready to Simplify Property Management?"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                    lineNumber: 102,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-lg text-muted-foreground mb-8",
                                    children: "Join landlords who are already managing their properties more efficiently with LandlordOS"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                    lineNumber: 105,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$BrowserBase__Pipeline$2f$website$2d$genesis$2d$output$2f$landlordos$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/signup",
                                    className: "inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-primary rounded-lg hover:bg-primary/90 transition-colors",
                                    children: "Start Free Trial"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                                    lineNumber: 108,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                        lineNumber: 100,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/BrowserBase Pipeline/website-genesis-output/landlordos/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__157bf4a3._.js.map