globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/19c6c06776498b9a.js",
    "static/chunks/006ce42230ca8bd6.js",
    "static/chunks/62dadc683e92cad4.js",
    "static/chunks/92f3da5e22e3aced.js",
    "static/chunks/turbopack-f7a55a6c743022d2.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];