var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__a3c9d651._.js")
R.c("server/chunks/[root-of-the-server]__bfc4743c._.js")
R.c("server/chunks/2e868_landlordos__next-internal_server_app_robots_txt_route_actions_521bb8e2.js")
R.m(54623)
module.exports=R.m(54623).exports
