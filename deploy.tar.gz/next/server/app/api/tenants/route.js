var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tenants/route.js")
R.c("server/chunks/[root-of-the-server]__4e99ce90._.js")
R.c("server/chunks/05d6d_drizzle-orm_9eb90d65._.js")
R.c("server/chunks/Desktop_BrowserBase Pipeline_website-genesis-output_landlordos_870541e6._.js")
R.c("server/chunks/[root-of-the-server]__bfc4743c._.js")
R.c("server/chunks/3d860_BrowserBase Pipeline_website-genesis-output_landlordos_lib_db_ts_e5e89481._.js")
R.c("server/chunks/2e868_landlordos__next-internal_server_app_api_tenants_route_actions_4d715212.js")
R.m(52660)
module.exports=R.m(52660).exports
