var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__6bcd8eb3._.js")
R.c("server/chunks/[root-of-the-server]__bfc4743c._.js")
R.c("server/chunks/2e868_landlordos__next-internal_server_app_sitemap_xml_route_actions_56bc76f4.js")
R.m(38358)
module.exports=R.m(38358).exports
