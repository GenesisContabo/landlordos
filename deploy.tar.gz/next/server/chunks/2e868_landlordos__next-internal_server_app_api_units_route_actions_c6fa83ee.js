module.exports=[35773,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_api_units_route_actions_c6fa83ee.js.map