module.exports=[43319,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_api_tenants_%5Bid%5D_route_actions_66cc5174.js.map