module.exports=[17366,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_api_properties_route_actions_a5df4c9f.js.map