module.exports=[44906,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_api_properties_%5Bid%5D_route_actions_6f932f74.js.map