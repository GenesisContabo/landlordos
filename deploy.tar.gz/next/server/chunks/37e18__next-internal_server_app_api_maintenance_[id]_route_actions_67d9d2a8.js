module.exports=[99996,(e,o,d)=>{}];

//# sourceMappingURL=37e18__next-internal_server_app_api_maintenance_%5Bid%5D_route_actions_67d9d2a8.js.map