module.exports=[97491,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},10280,a=>{"use strict";let b={src:a.i(97491).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_BrowserBase%20Pipeline_website-genesis-output_landlordos_app_c3f9ceab._.js.map