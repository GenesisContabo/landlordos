module.exports=[43344,(a,b,c)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app__global-error_page_actions_496848ef.js.map