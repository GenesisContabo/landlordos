module.exports=[71944,(a,b,c)=>{}];

//# sourceMappingURL=37e18__next-internal_server_app_%28dashboard%29_properties_page_actions_d40c5d50.js.map