module.exports=[33478,(a,b,c)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app__not-found_page_actions_fec1d853.js.map