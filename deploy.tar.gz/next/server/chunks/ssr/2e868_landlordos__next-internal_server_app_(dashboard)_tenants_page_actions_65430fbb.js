module.exports=[20482,(a,b,c)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_%28dashboard%29_tenants_page_actions_65430fbb.js.map