module.exports=[25994,(a,b,c)=>{}];

//# sourceMappingURL=37e18__next-internal_server_app_%28dashboard%29_maintenance_page_actions_4e59fac7.js.map