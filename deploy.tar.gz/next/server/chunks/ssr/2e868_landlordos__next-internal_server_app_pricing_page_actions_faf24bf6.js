module.exports=[81268,(a,b,c)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_pricing_page_actions_faf24bf6.js.map