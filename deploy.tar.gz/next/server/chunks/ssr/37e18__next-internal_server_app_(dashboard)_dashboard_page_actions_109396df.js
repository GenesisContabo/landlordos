module.exports=[69783,(a,b,c)=>{}];

//# sourceMappingURL=37e18__next-internal_server_app_%28dashboard%29_dashboard_page_actions_109396df.js.map