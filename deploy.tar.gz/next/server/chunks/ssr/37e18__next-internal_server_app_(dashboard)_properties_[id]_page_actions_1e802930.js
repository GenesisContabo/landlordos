module.exports=[42234,(a,b,c)=>{}];

//# sourceMappingURL=37e18__next-internal_server_app_%28dashboard%29_properties_%5Bid%5D_page_actions_1e802930.js.map