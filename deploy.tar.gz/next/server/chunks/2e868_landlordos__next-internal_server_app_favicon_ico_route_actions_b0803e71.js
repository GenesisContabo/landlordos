module.exports=[81536,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_favicon_ico_route_actions_b0803e71.js.map