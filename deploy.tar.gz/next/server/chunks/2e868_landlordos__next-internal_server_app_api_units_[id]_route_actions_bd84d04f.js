module.exports=[56616,(e,o,d)=>{}];

//# sourceMappingURL=2e868_landlordos__next-internal_server_app_api_units_%5Bid%5D_route_actions_bd84d04f.js.map